module.exports = {
  botName: process.env.BOT_NAME || "WhasBot",
  prefix: process.env.PREFIX || "/"
};