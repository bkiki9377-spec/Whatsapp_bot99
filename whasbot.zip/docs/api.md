# Gemini API

ضع المفتاح في ملف .env:
GEMINI_API_KEY=xxx